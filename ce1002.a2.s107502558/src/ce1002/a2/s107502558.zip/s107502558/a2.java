/*
 * Assignment 2
 * Course: ce1002
 * Name: �f�ɿ�
 * Student ID: 107502558
 */
package ce1002.a2.s107502558;

import java.util.Scanner;

public class a2 {

	public static void main(String[] args) {
		int max=0;
		String winner = " ";
		Scanner input = new Scanner(System.in);
		for(;;){
		
		String name = input.next(); //nextLine�|Ū��� ����
		if(name.equals("null")){ //��C++���P �`�N
			break;
		}
		int score = input.nextInt();
		
		if(max<score) {
			max=score;
			winner=name;
		}
		}
		System.out.print("Winner is "+winner+": "+max); //+�i�H�r��걵
	}

}
