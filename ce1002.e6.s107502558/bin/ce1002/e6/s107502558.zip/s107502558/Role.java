package ce1002.e6.s107502558;

public class Role {
	String Name;
	int Hp;
	int Atk;
}
